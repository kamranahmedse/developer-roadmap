## developer-roadmap
 Roadmap to becoming a web developer in 2020

[![](httpsimg.shields.iobadge-Roadmaps%20-0a0a0a.svgstyle=flat&colorA=0a0a0a)](httproadmap.sh)
[![](httpsimg.shields.iobadge-Guides-0a0a0a.svgstyle=flat&colorA=0a0a0a)](httproadmap.shguides)
[![](httpsimg.shields.iobadge%E2%9D%A4-YouTube%20Channel-0a0a0a.svgstyle=flat&colorA=0a0a0a)](httpswww.youtube.comchannelUCA0H2KIWgWTwpTFjSxp0nowplaylists)

## Introduction

![Web Developer Roadmap Introduction](.imgintro.png)

## Backend Roadmap

![](.imgbackend-map.png)


## Frontend Roadmap

 [Help us translate](httpsgithub.comkamranahmedsedeveloper-roadmapissues669)

## DevOps Roadmap

 [Help us translate](httpsgithub.comkamranahmedsedeveloper-roadmapissues669)